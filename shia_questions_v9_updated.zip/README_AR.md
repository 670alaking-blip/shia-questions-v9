# مسابقة الحسنات — مشروع V1

هذا مشروع Flutter كامل البنية لنسخة أولى قابلة للتوسع.

## تشغيل
flutter pub get
flutter run

## APK
flutter build apk --release

## دعم Android
الحد الأدنى المستهدف: Android 8 (API 26).
للنشر على Google Play في 2026: target API 36 أو أعلى وفق متطلبات Google Play.

## قاعدة الأسئلة
ضع ملف `assets/questions.json` النهائي الذي يحتوي 3000 سؤال بنفس الحقول:
id, category, difficulty, question, options, correct, explanation, source

لا يتم توليد 3000 سؤال ديني آليًا؛ يجب مراجعتها من مصادر موثوقة قبل النشر.
## الموقع
`website/index.html` هو موقع التحميل الرسمي. عند امتلاك APK النهائي، ضعه بجانب الصفحة باسم `APP-RELEASE.apk`.


## شهادات المراكز الثلاثة
توجد واجهة لشهادات تقديرية للمراكز الأول والثاني والثالث، وتُعرض بعد اعتماد نتائج البطولة الشهرية من السيرفر.
