# Firebase Functions — V9

الفكرة:
- `users/{uid}.hasanat` = الحسنات الدائمة ولا تُصفّر شهرياً.
- `monthly_scores/{uid}` = نقاط المتصدرين للشهر الحالي فقط.
- `monthly_winners/{monthKey}` = أرشيف الفائزين بالأشهر السابقة.

في الإنتاج، تحديث `monthly_scores` يجب أن يتم عبر Cloud Functions أو Backend موثوق، وليس من العميل مباشرة، لمنع الغش.

وظيفة شهرية مقترحة:
1. في بداية الشهر الجديد، يُنشأ monthKey جديد بصيغة YYYY-MM.
2. المتصدرون الجدد يبدأون من 0.
3. الشهر السابق يبقى محفوظاً في monthly_winners.
4. `users.hasanat` لا يتغير بسبب تبديل الشهر.

قبل النشر الفعلي يجب إنشاء Firebase project وربطه بالمشروع بواسطة FlutterFire (`flutterfire configure`) ثم إضافة `google-services.json` للتطبيق. لا تضع ملفات Firebase السرية أو مفاتيح الخادم داخل مستودع عام.
