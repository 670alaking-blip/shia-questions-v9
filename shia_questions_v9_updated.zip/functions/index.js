// V9 backend starter.
// Deploy only after creating your Firebase project and configuring the Functions environment.
// This function demonstrates monthly rollover without touching permanent hasanat.

const {onSchedule} = require("firebase-functions/v2/scheduler");
const {getFirestore, FieldValue} = require("firebase-admin/firestore");
const {initializeApp} = require("firebase-admin/app");

initializeApp();
const db = getFirestore();

exports.monthlyRollover = onSchedule("0 0 1 * *", async () => {
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, "0");
  const currentMonth = `${year}-${month}`;

  // The app uses a new monthKey, so new monthly scores start at zero.
  // Permanent users/{uid}.hasanat is intentionally untouched.
  await db.collection("system").doc("leaderboard").set({
    currentMonth,
    updatedAt: FieldValue.serverTimestamp()
  }, {merge: true});
});
