طريقة بناء APK من GitHub من الموبايل:

1) افتح github.com وسجل الدخول.
2) أنشئ Repository جديد باسم shia-questions.
3) ارفع كل ملفات هذا المشروع إلى المستودع، خصوصاً pubspec.yaml وlib وassets و.github.
4) افتح تبويب Actions.
5) اختر Build APK. إذا بدأ تلقائياً بعد الرفع انتظر انتهاءه، أو اضغط Run workflow.
6) افتح العملية الناجحة، ثم في الأسفل Artifacts اضغط shia-questions-release-apk.
7) نزّل الملف المضغوط وفك الضغط لتحصل على app-release.apk.
8) هذا APK يظهر كبرنامج عادي بعد تثبيته.

التوافق مضبوط ليبدأ من Android 8 (API 26). التوافق مع Android 16 يعتمد على جهاز وإصدار Android، والكود لا يستخدم APIs أحدث من الحد الأدنى بشكل مباشر.
