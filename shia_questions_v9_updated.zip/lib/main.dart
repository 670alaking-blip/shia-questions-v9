import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const green = Color(0xFF0B765B);
const darkGreen = Color(0xFF064D3D);
const gold = Color(0xFFE3B341);

class Question {
  final int id, correct;
  final String category, difficulty, question, explanation, source;
  final List<String> options;
  Question({required this.id,required this.category,required this.difficulty,required this.question,
    required this.options,required this.correct,required this.explanation,required this.source});
  factory Question.fromJson(Map<String,dynamic> j)=>Question(
    id:j['id'],category:j['category'],difficulty:j['difficulty'],question:j['question'],
    options:List<String>.from(j['options']),correct:j['correct'],
    explanation:j['explanation'] ?? '',source:j['source'] ?? '');
  int get right => difficulty=='سهل'?1:difficulty=='متوسط'?5:10;
  // V9 rule: every wrong answer is -2, regardless of difficulty.
  int get wrong => 2;
}

class AppState extends ChangeNotifier {
  int hasanat=0,total=0,correct=0,streak=0,best=0,monthlyPoints=0;
  final List<Map<String,dynamic>> pendingEvents=[];

  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    hasanat=p.getInt('hasanat')??0; total=p.getInt('total')??0;
    correct=p.getInt('correct')??0; streak=p.getInt('streak')??0; best=p.getInt('best')??0;
    monthlyPoints=p.getInt('monthlyPoints')??0;
    notifyListeners();
  }

  Future<void> result(bool ok,int delta,{required int questionId}) async {
    hasanat=max(0,hasanat+delta); total++;
    monthlyPoints=max(0,monthlyPoints+delta);
    if(ok){correct++;streak++;best=max(best,streak);}else{streak=0;}
    final p=await SharedPreferences.getInstance();
    await p.setInt('hasanat',hasanat); await p.setInt('total',total);
    await p.setInt('correct',correct); await p.setInt('streak',streak); await p.setInt('best',best);
    await p.setInt('monthlyPoints',monthlyPoints);
    // Queue the event so a future Firebase sync can submit it once internet returns.
    final events=p.getStringList('pendingEvents')??[];
    events.add(jsonEncode({'id':'${DateTime.now().microsecondsSinceEpoch}_$questionId','questionId':questionId,'delta':delta,'ok':ok,'at':DateTime.now().toIso8601String()}));
    await p.setStringList('pendingEvents',events);
    notifyListeners();
  }

  Future<void> reset() async {
    hasanat=total=correct=streak=best=monthlyPoints=0;
    final p=await SharedPreferences.getInstance();
    for(final k in ['hasanat','total','correct','streak','best','monthlyPoints','pendingEvents']) await p.remove(k);
    notifyListeners();
  }
}

Future<List<Question>> loadQuestions() async {
  final raw=await rootBundle.loadString('assets/questions.json');
  return (jsonDecode(raw) as List).map((e)=>Question.fromJson(e)).toList();
}

void main() => runApp(const HasanatApp());

class HasanatApp extends StatelessWidget {
  const HasanatApp({super.key});
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'أسئلة شيعية',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:green,scaffoldBackgroundColor:const Color(0xFFF7F9F7)),
    home:const Directionality(textDirection:TextDirection.rtl,child:Home()),
  );
}

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home>{
  final s=AppState(); List<Question> qs=[];
  @override void initState(){super.initState();s.load();loadQuestions().then((v)=>setState(()=>qs=v));}
  void quiz(String? cat)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Quiz(qs:qs,category:cat,state:s)));
  @override Widget build(BuildContext c)=>ListenableBuilder(listenable:s,builder:(_,__) {
    final rate=s.total==0?0:(s.correct/s.total*100).round();
    return Scaffold(
      appBar:AppBar(title:const Text('أسئلة شيعية',style:TextStyle(fontWeight:FontWeight.w900)),centerTitle:true),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(
          gradient:const LinearGradient(colors:[darkGreen,green]),borderRadius:BorderRadius.circular(28)),
          child:Column(children:[
            const Icon(Icons.auto_awesome,color:gold,size:34),const SizedBox(height:6),
            const Text('رصيد الحسنات الدائم',style:TextStyle(color:Colors.white70)),
            Text('${s.hasanat}',style:const TextStyle(color:Colors.white,fontSize:48,fontWeight:FontWeight.w900)),
            const Text('حسنة — لا تُصفّر شهريًا',style:TextStyle(color:Colors.white)),
          ])),
        const SizedBox(height:12),
        Row(children:[stat('الأسئلة','${s.total}',Icons.quiz),stat('النجاح','$rate%',Icons.analytics),stat('أفضل سلسلة','${s.best}',Icons.local_fire_department)]),
        const SizedBox(height:12),
        Card(child:ListTile(leading:const Icon(Icons.emoji_events),title:const Text('البطولة الشهرية',style:TextStyle(fontWeight:FontWeight.bold)),
          subtitle:Text('نقاط هذا الشهر: ${s.monthlyPoints}\nتُحفظ نتائج اللعب بدون إنترنت وتنتظر المزامنة.'),
          trailing:const Icon(Icons.arrow_back_ios_new,size:15),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChampionsPage(state:s)))),
        const SizedBox(height:8),
        const Text('اختر المسابقة',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        mode('اختبار عشوائي','10 أسئلة من جميع الأقسام',Icons.shuffle,null),
        mode('القرآن','أسئلة القرآن وعلومه',Icons.menu_book,'القرآن'),
        mode('أهل البيت','أسئلة أهل البيت عليهم السلام',Icons.favorite,'أهل البيت'),
        mode('العقائد','العقائد الإمامية',Icons.auto_awesome,'العقائد'),
        mode('الفقه','أحكام فقهية متنوعة',Icons.balance,'الفقه'),
        mode('السيرة','السيرة والتاريخ',Icons.history,'السيرة'),
        const SizedBox(height:8),
        Card(child:ListTile(leading:const Icon(Icons.stars),title:const Text('نظام الحسنات'),
          subtitle:const Text('الصحيح: سهل +1 • متوسط +5 • صعب +10\nالخطأ: −2 حسنة في جميع الصعوبات'))),
        Card(child:ListTile(leading:const Icon(Icons.restart_alt),title:const Text('تصفير الإحصائيات'),
          onTap:()=>showDialog(context:context,builder:(_)=>AlertDialog(
            title:const Text('تصفير الإحصائيات؟'),content:const Text('سيتم حذف الحسنات والإحصائيات من هذا الجهاز.'),
            actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),
              FilledButton(onPressed:(){s.reset();Navigator.pop(context);},child:const Text('تصفير'))])))),
      ]));
  });
  Widget stat(String a,String b,IconData i)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.symmetric(vertical:13),
    child:Column(children:[Icon(i,size:22),const SizedBox(height:3),Text(b,style:const TextStyle(fontWeight:FontWeight.bold)),Text(a,style:const TextStyle(fontSize:11))]))));
  Widget mode(String a,String b,IconData i,String? cat)=>Card(child:ListTile(onTap:()=>quiz(cat),
    leading:CircleAvatar(child:Icon(i)),title:Text(a,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(b),
    trailing:const Icon(Icons.arrow_back_ios_new,size:15)));
}

class ChampionsPage extends StatelessWidget {
  final AppState state;
  const ChampionsPage({super.key,required this.state});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('أبطال الأشهر',style:TextStyle(fontWeight:FontWeight.w900))),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Card(child:Padding(padding:EdgeInsets.all(16),child:Text(
        'هنا تظهر الشهادات التقديرية للمراكز الثلاثة الأولى بعد اعتماد نتائج الشهر من السيرفر.',
        style:TextStyle(height:1.6)))),
      const SizedBox(height:12),
      CertificateCard(place:1,title:'بطل الشهر',icon:Icons.emoji_events,color:gold,player:'اسم اللاعب',score:'—',month:'الشهر الحالي'),
      CertificateCard(place:2,title:'الوصيف',icon:Icons.workspace_premium,color:Colors.blueGrey,player:'اسم اللاعب',score:'—',month:'الشهر الحالي'),
      CertificateCard(place:3,title:'المركز الثالث',icon:Icons.workspace_premium,color:Colors.brown,player:'اسم اللاعب',score:'—',month:'الشهر الحالي'),
    ]));
}

class CertificateCard extends StatelessWidget {
  final int place; final String title,player,score,month; final IconData icon; final Color color;
  const CertificateCard({super.key,required this.place,required this.title,required this.icon,required this.color,required this.player,required this.score,required this.month});
  @override Widget build(BuildContext context)=>Card(
    margin:const EdgeInsets.only(bottom:14),
    child:Container(decoration:BoxDecoration(border:Border.all(color:color,width:2),borderRadius:BorderRadius.circular(22)),padding:const EdgeInsets.all(18),
      child:Column(children:[
        Icon(icon,color:color,size:46),const SizedBox(height:6),
        Text('شهادة المركز $place',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900,color:color)),
        Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        Text(player,style:const TextStyle(fontSize:21,fontWeight:FontWeight.w800)),
        const SizedBox(height:8),
        Text('مجموع الحسنات في البطولة: $score'),
        Text('الشهر: $month'),
        const SizedBox(height:8),
        const Text('أسئلة شيعية',style:TextStyle(fontWeight:FontWeight.bold)),
      ]));
}

class Quiz extends StatefulWidget {
  final List<Question> qs; final String? category; final AppState state;
  const Quiz({super.key,required this.qs,this.category,required this.state});
  @override State<Quiz> createState()=>_QuizState();
}
class _QuizState extends State<Quiz>{
  late List<Question> list; int pos=0; int? selected; bool answered=false; int earned=0;
  @override void initState(){super.initState(); final x=widget.category==null?widget.qs:widget.qs.where((q)=>q.category==widget.category).toList();
    x.shuffle(Random());list=x.take(min(10,x.length)).toList();}
  void pick(int i){if(answered)return; final q=list[pos]; final ok=i==q.correct; final d=ok?q.right:-q.wrong;
    setState((){selected=i;answered=true;earned+=d;});widget.state.result(ok,d,questionId:q.id);}
  void next(){if(pos+1==list.length){Navigator.pop(context);return;}setState((){pos++;selected=null;answered=false;});}
  @override Widget build(BuildContext c){final q=list[pos];
    return Scaffold(appBar:AppBar(title:Text('السؤال ${pos+1} من ${list.length}'),actions:[Padding(padding:const EdgeInsets.all(12),child:Text('$earned حسنة'))]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        LinearProgressIndicator(value:(pos+1)/list.length,minHeight:7,borderRadius:BorderRadius.circular(8)),
        const SizedBox(height:14),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Chip(label:Text(q.category)),Chip(label:Text(q.difficulty))]),
        Card(child:Padding(padding:const EdgeInsets.all(20),child:Text(q.question,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold,height:1.45)))),
        const SizedBox(height:8),
        ...List.generate(q.options.length,(i)=>Card(child:ListTile(
          onTap:()=>pick(i),leading:CircleAvatar(child:Text('${i+1}')),
          title:Text(q.options[i]),trailing:answered?(i==q.correct?const Icon(Icons.check_circle,color:Colors.green):i==selected?const Icon(Icons.cancel,color:Colors.red):null):null))),
        if(answered) Card(color:const Color(0xFFEFF7F2),child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(selected==q.correct?'إجابة صحيحة 🎉':'إجابة خاطئة ❌',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
          const SizedBox(height:6),Text('الإجابة الصحيحة: ${q.options[q.correct]}'),
          if(q.explanation.isNotEmpty)Padding(padding:const EdgeInsets.only(top:6),child:Text(q.explanation)),
          Padding(padding:const EdgeInsets.only(top:6),child:Text('المصدر: ${q.source}')),
          Padding(padding:const EdgeInsets.only(top:6),child:Text(selected==q.correct?'+${q.right} حسنة':'−2 حسنة',style:const TextStyle(fontWeight:FontWeight.bold))),
        ]))),
        if(answered)Padding(padding:const EdgeInsets.only(top:8),child:FilledButton(onPressed:next,child:Text(pos+1==list.length?'إنهاء':'السؤال التالي'))),
      ]));
  }
}
